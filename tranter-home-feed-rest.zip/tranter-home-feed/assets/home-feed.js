(function(){
  function init(root){
    var items=[].slice.call(root.querySelectorAll('.tfh-item')),i=0,t;
    if(items.length<2){root.classList.add('is-single');return;}
    function show(n){
      items[i].classList.remove('is-active');items[i].querySelector('a').setAttribute('tabindex','-1');
      i=(n+items.length)%items.length;
      items[i].classList.add('is-active');items[i].querySelector('a').removeAttribute('tabindex');
    }
    function stop(){clearInterval(t);}
    function play(){stop();if(window.matchMedia&&matchMedia('(prefers-reduced-motion:reduce)').matches)return;t=setInterval(function(){show(i+1);},5500);}
    root.querySelector('.tfh-prev').addEventListener('click',function(){show(i-1);play();});
    root.querySelector('.tfh-next').addEventListener('click',function(){show(i+1);play();});
    root.addEventListener('mouseenter',stop);root.addEventListener('mouseleave',play);
    root.addEventListener('focusin',stop);root.addEventListener('focusout',play);
    play();
  }
  function boot(){[].forEach.call(document.querySelectorAll('.tfh-banner'),init);}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
