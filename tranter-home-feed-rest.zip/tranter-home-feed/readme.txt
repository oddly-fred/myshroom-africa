=== Tranter Home Feed ===
Version: 1.2.0

Feeds the Tranter IT homepage with manual News, Offers, Events and Blog updates, upcoming events, and latest WordPress posts.

== Install ==
1. In WordPress, open Plugins > Add New > Upload Plugin.
2. Upload tranter-home-feed-updated.zip.
3. Activate Tranter Home Feed.
4. Confirm that Tranter IT Events is active if you want event items and the homepage Events section.

== Homepage setup ==
The generated homepage uses an Elementor Shortcode widget for the live feed. Add this shortcode where the feed banner should appear:

[tranter_updates_banner events="3" posts="2" manual="5" events_url="/events/"]

Do not place this shortcode in an Elementor HTML widget. Use Elementor's Shortcode widget so WordPress can execute it.

== Events section ==
To render the designed homepage Events section, use:

[tranter_home_events limit="4" events_url="/events/"]

The events_url must point to the page containing [tranter_events]. Event cards link to the matching event popup on that page.

== Adding updates ==
Go to WordPress menu > Home Updates. Add a headline, choose News, Offer, Event or Blog, paste a link, optionally add supporting text, set an expiry date, and optionally pin the update first.

Upcoming events and the newest published WordPress posts are added automatically to the feed.

== Elementor HTML widget ==
The plugin exposes a read-only feed endpoint at /wp-json/tranter-home/v1/updates. The generated homepage HTML widget requests this endpoint automatically; no PHP shortcode is required inside the HTML widget.
