<?php
/**
 * Plugin Name: Tranter Home Feed
 * Description: Elementor-compatible homepage feed with manual News, Offers, Events and Blog updates, plus upcoming events and latest posts.
 * Version: 1.1.1
 * Author: Tranter IT
 * Text Domain: tranter-home-feed
 */
if (!defined('ABSPATH')) exit;

final class Tranter_Home_Feed {
    const CPT       = 'tranter_update';
    const NONCE     = 'tranter_home_feed_nonce';
    const EVENT_CPT = 'tranter_event';
    const TYPE_TAX  = 'tranter_event_type';
    private static $assets_done = false;

    public function __construct() {
        add_action('init', [$this, 'register']);
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_post_tfh_save', [$this, 'handle_save']);
        add_action('admin_post_tfh_delete', [$this, 'handle_delete']);
        add_shortcode('tranter_updates_banner', [$this, 'banner']);
        add_shortcode('tranter_home_events', [$this, 'events']);
    }

    /* ---------- Admin: one simple "Home Updates" page ---------- */

    public function register() {
        register_post_type(self::CPT, [
            'labels' => ['name' => 'Home Updates', 'singular_name' => 'Home Update'],
            'public' => false, 'show_ui' => false, 'show_in_menu' => false, 'supports' => ['title'],
            'capability_type' => 'post', 'map_meta_cap' => true,
        ]);
    }

    public function menu() {
        add_menu_page('Home Updates', 'Home Updates', 'edit_posts', 'tranter-home-updates', [$this, 'page'], 'dashicons-megaphone', 26);
    }

    private function post_value($key) {
        return isset($_POST[$key]) ? wp_unslash($_POST[$key]) : '';
    }

    private function kinds() {
        return ['news' => 'News', 'offer' => 'Offer', 'event' => 'Event', 'blog' => 'Blog'];
    }

    public function page() {
        if (!current_user_can('edit_posts')) return;
        $edit = isset($_GET['edit']) ? absint($_GET['edit']) : 0;
        $v = ['title' => '', 'kind' => 'news', 'url' => '', 'note' => '', 'exp' => '', 'pin' => '0'];
        if ($edit) {
            $p = get_post($edit);
            if ($p && $p->post_type === self::CPT) {
                $k = get_post_meta($edit, 'tfh_kind', true);
                $v = ['title' => $p->post_title, 'kind' => $k ? $k : 'news', 'url' => get_post_meta($edit, 'tfh_url', true),
                      'note' => get_post_meta($edit, 'tfh_note', true), 'exp' => get_post_meta($edit, 'tfh_expires', true),
                      'pin' => get_post_meta($edit, 'tfh_pin', true)];
            } else {
                $edit = 0;
            }
        }
        $base = admin_url('admin.php?page=tranter-home-updates');
        echo '<style>.tfh-a{max-width:980px}.tfh-a .card{max-width:none;padding:20px 24px;margin-top:16px}.tfh-a label.l{display:block;margin:14px 0 4px;font-weight:600}.tfh-a .hint{color:#646970;font-weight:400}.tfh-a input[type=text],.tfh-a input[type=url],.tfh-a input[type=date]{width:100%;max-width:560px}.tfh-a .kinds label{display:inline-block;margin:0 8px 8px 0;padding:8px 16px;border:1px solid #c3c4c7;border-radius:999px;cursor:pointer;background:#fff}.tfh-a .kinds input{margin-right:6px}.tfh-a .kinds label:has(input:checked){background:#00A651;border-color:#00A651;color:#fff}.tfh-a .exp{opacity:.55}</style>';
        echo '<div class="wrap tfh-a"><h1>Home Updates</h1>';
        echo '<p>Anything you add here appears in the green banner under the home page header. Upcoming events and the newest blog posts are added automatically, so you only add offers, news and anything else you want to announce.</p>';
        if (isset($_GET['saved'])) echo '<div class="notice notice-success is-dismissible"><p>Saved. It is live on the home page.</p></div>';
        if (isset($_GET['deleted'])) echo '<div class="notice notice-success is-dismissible"><p>Removed.</p></div>';
        if (isset($_GET['error'])) echo '<div class="notice notice-error"><p>Please type a headline first.</p></div>';

        echo '<div class="card"><h2 style="margin-top:0">' . ($edit ? 'Edit update' : 'Add an update') . '</h2>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="tfh_save"><input type="hidden" name="tfh_id" value="' . (int) $edit . '">';
        wp_nonce_field(self::NONCE);
        echo '<label class="l" for="tfh_title">1. Headline <span class="hint">(what visitors read, keep it short)</span></label><input type="text" id="tfh_title" name="tfh_title" maxlength="90" required value="' . esc_attr($v['title']) . '" placeholder="Example: Free IT health check for new clients">';
        echo '<label class="l">2. What kind of update is it?</label><div class="kinds">';
        foreach ($this->kinds() as $k => $l) {
            echo '<label><input type="radio" name="tfh_kind" value="' . esc_attr($k) . '"' . checked($v['kind'], $k, false) . '>' . esc_html($l) . '</label>';
        }
        echo '</div>';
        echo '<label class="l" for="tfh_url">3. Link <span class="hint">(the page it should open, paste the full address)</span></label><input type="url" id="tfh_url" name="tfh_url" value="' . esc_attr($v['url']) . '" placeholder="https://">';
        echo '<label class="l" for="tfh_note">4. Small extra text <span class="hint">(optional, for example: Ends 30 Nov)</span></label><input type="text" id="tfh_note" name="tfh_note" maxlength="60" value="' . esc_attr($v['note']) . '">';
        echo '<label class="l" for="tfh_expires">5. Hide it automatically after <span class="hint">(optional)</span></label><input type="date" id="tfh_expires" name="tfh_expires" value="' . esc_attr($v['exp']) . '">';
        echo '<label class="l"><input type="checkbox" name="tfh_pin" value="1"' . checked($v['pin'], '1', false) . '> Show this one first</label>';
        echo '<p style="margin-top:20px"><button class="button button-primary button-hero" type="submit">' . ($edit ? 'Save changes' : 'Publish update') . '</button>';
        if ($edit) echo ' <a class="button button-hero" href="' . esc_url($base) . '">Cancel</a>';
        echo '</p></form></div>';

        $posts = get_posts(['post_type' => self::CPT, 'post_status' => 'publish', 'numberposts' => 100]);
        echo '<div class="card"><h2 style="margin-top:0">Your updates</h2>';
        if (!$posts) {
            echo '<p>Nothing here yet. Add your first update above.</p>';
        } else {
            $today = current_time('Y-m-d');
            echo '<table class="widefat striped"><thead><tr><th>Headline</th><th>Type</th><th>Hides after</th><th></th></tr></thead><tbody>';
            foreach ($posts as $p) {
                $k = get_post_meta($p->ID, 'tfh_kind', true);
                $kinds = $this->kinds();
                $e = get_post_meta($p->ID, 'tfh_expires', true);
                $gone = $e && $e < $today;
                echo '<tr' . ($gone ? ' class="exp"' : '') . '><td><strong>' . esc_html($p->post_title) . '</strong>';
                if (get_post_meta($p->ID, 'tfh_pin', true) === '1') echo ' <span class="hint">(shown first)</span>';
                if ($gone) echo '<br><span class="hint">Expired, no longer shown</span>';
                echo '</td><td>' . esc_html(isset($kinds[$k]) ? $kinds[$k] : 'News') . '</td><td>' . esc_html($e ? $e : 'Never') . '</td><td>';
                echo '<a href="' . esc_url($base . '&edit=' . $p->ID) . '">Edit</a> | ';
                echo '<a href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=tfh_delete&id=' . $p->ID), self::NONCE)) . '" onclick="return confirm(\'Remove this update?\')">Remove</a>';
                echo '</td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div></div>';
    }

    public function handle_save() {
        if (!current_user_can('edit_posts')) wp_die('Not allowed');
        check_admin_referer(self::NONCE);
        $base = admin_url('admin.php?page=tranter-home-updates');
        $title = sanitize_text_field($this->post_value('tfh_title'));
        if ($title === '') {
            wp_safe_redirect($base . '&error=1');
            exit;
        }
        $id = isset($_POST['tfh_id']) ? absint($_POST['tfh_id']) : 0;
        $args = ['post_type' => self::CPT, 'post_status' => 'publish', 'post_title' => wp_slash($title)];
        if ($id && get_post_type($id) === self::CPT) {
            $args['ID'] = $id;
            wp_update_post($args);
        } else {
            $id = wp_insert_post($args);
        }
        if ($id && !is_wp_error($id)) {
            $kind = sanitize_key($this->post_value('tfh_kind'));
            if (!isset($this->kinds()[$kind])) $kind = 'news';
            $exp = sanitize_text_field($this->post_value('tfh_expires'));
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $exp)) $exp = '';
            update_post_meta($id, 'tfh_kind', $kind);
            update_post_meta($id, 'tfh_url', esc_url_raw($this->post_value('tfh_url')));
            update_post_meta($id, 'tfh_note', sanitize_text_field($this->post_value('tfh_note')));
            update_post_meta($id, 'tfh_expires', $exp);
            update_post_meta($id, 'tfh_pin', isset($_POST['tfh_pin']) ? '1' : '0');
        }
        wp_safe_redirect($base . '&saved=1');
        exit;
    }

    public function handle_delete() {
        if (!current_user_can('edit_posts')) wp_die('Not allowed');
        check_admin_referer(self::NONCE);
        $id = isset($_GET['id']) ? absint($_GET['id']) : 0;
        if ($id && get_post_type($id) === self::CPT) wp_delete_post($id, true);
        wp_safe_redirect(admin_url('admin.php?page=tranter-home-updates&deleted=1'));
        exit;
    }

    /* ---------- Data (same meta keys and date logic as Tranter IT Events) ---------- */

    private function assets() {
        if (self::$assets_done) return '';
        self::$assets_done = true;
        $dir = plugin_dir_path(__FILE__) . 'assets/';
        $css = file_exists($dir . 'home-feed.css') ? file_get_contents($dir . 'home-feed.css') : '';
        $js  = file_exists($dir . 'home-feed.js') ? file_get_contents($dir . 'home-feed.js') : '';
        return '<style>' . $css . '</style><script>' . $js . '</script>';
    }

    private function meta($id) {
        $keys = ['start_date', 'end_date', 'start_time', 'end_time', 'timezone', 'location_name', 'location_city',
                 'registration_enabled', 'registration_url', 'registration_text', 'short_description'];
        $m = [];
        foreach ($keys as $k) $m[$k] = get_post_meta($id, $k, true);
        if (!$m['timezone']) $m['timezone'] = 'Africa/Lagos';
        return $m;
    }

    private function ts($m, $end = false) {
        $date = ($end && $m['end_date']) ? $m['end_date'] : $m['start_date'];
        if (!$date) return 0;
        if ($end && $m['end_time']) $time = $m['end_time'];
        else $time = $m['start_time'] ? $m['start_time'] : '00:00';
        try {
            $tz = new DateTimeZone($m['timezone']);
            $dt = new DateTime($date . ' ' . $time, $tz);
            return $dt->getTimestamp();
        } catch (Exception $e) {
            return 0;
        }
    }

    private function image($id) {
        $img = get_the_post_thumbnail_url($id, 'large');
        if ($img) return $img;
        $g = get_post_meta($id, 'gallery', true);
        if (is_array($g)) {
            foreach ($g as $x) {
                $u = is_numeric($x) ? wp_get_attachment_image_url((int) $x, 'large') : esc_url_raw($x);
                if ($u) return $u;
            }
        }
        return '';
    }

    private function load_events() {
        $posts = get_posts(['post_type' => self::EVENT_CPT, 'post_status' => 'publish', 'numberposts' => -1]);
        $up = [];
        $past = [];
        $now = time();
        foreach ($posts as $p) {
            $m = $this->meta($p->ID);
            $s = $this->ts($m);
            if (!$s) continue;
            $e = $this->ts($m, true);
            if (!$e) $e = $s;
            $t = get_the_terms($p->ID, self::TYPE_TAX);
            $short = $m['short_description'];
            if (!$short) $short = wp_trim_words(wp_strip_all_tags($p->post_content), 22);
            $row = [
                'id' => $p->ID, 'title' => get_the_title($p), 'm' => $m, 'start' => $s, 'end' => $e,
                'type' => ($t && !is_wp_error($t)) ? $t[0]->name : 'Event',
                'image' => $this->image($p->ID), 'short' => $short,
                'where' => implode(', ', array_filter([$m['location_name'], $m['location_city']])),
            ];
            if ($now <= $e) $up[] = $row; else $past[] = $row;
        }
        usort($up, function ($a, $b) { return $a['start'] - $b['start']; });
        usort($past, function ($a, $b) { return $b['start'] - $a['start']; });
        return [$up, $past];
    }

    private function manual($limit) {
        $today = current_time('Y-m-d');
        $posts = get_posts(['post_type' => self::CPT, 'post_status' => 'publish', 'numberposts' => 50]);
        $out = [];
        foreach ($posts as $p) {
            $exp = get_post_meta($p->ID, 'tfh_expires', true);
            if ($exp && $exp < $today) continue;
            $kind = get_post_meta($p->ID, 'tfh_kind', true);
            $url = get_post_meta($p->ID, 'tfh_url', true);
            $out[] = [
                'kind' => $kind ? $kind : 'news', 'title' => get_the_title($p),
                'meta' => (string) get_post_meta($p->ID, 'tfh_note', true),
                'url' => $url ? $url : '#', 'pin' => get_post_meta($p->ID, 'tfh_pin', true) === '1',
            ];
        }
        return array_slice($out, 0, $limit);
    }

    private function date_label($s, $e) {
        if ($e && wp_date('Ymd', $e) !== wp_date('Ymd', $s)) {
            if (wp_date('M Y', $s) === wp_date('M Y', $e)) return wp_date('j', $s) . '-' . wp_date('j M Y', $e);
            return wp_date('j M', $s) . ' - ' . wp_date('j M Y', $e);
        }
        return wp_date('j M Y', $s);
    }

    private function when($e) {
        $now = time();
        if ($now >= $e['start'] && $now <= $e['end']) return 'Happening now';
        if ($e['start'] < $now) return '';
        if (wp_date('Ymd', $e['start']) === wp_date('Ymd')) return 'Today';
        $d = (int) ceil(($e['start'] - $now) / 86400);
        return $d <= 1 ? 'Tomorrow' : 'In ' . $d . ' days';
    }

    private function event_url($base, $id) {
        $base = $base ? $base : '/events/';
        $base = preg_replace('/#.*$/', '', $base);
        return $base . '#tranter-event-' . (int) $id;
    }

    /* ---------- [tranter_updates_banner] ---------- */

    public function banner($atts) {
        $a = shortcode_atts(['events' => 3, 'posts' => 2, 'manual' => 5, 'events_url' => '/events/'], $atts, 'tranter_updates_banner');
        $labels = ['event' => 'Event', 'blog' => 'Blog', 'offer' => 'Offer', 'news' => 'News'];
        $manual = $this->manual((int) $a['manual']);
        $items = [];
        foreach ($manual as $x) if ($x['pin']) $items[] = $x;
        $ev = $this->load_events();
        foreach (array_slice($ev[0], 0, (int) $a['events']) as $e) {
            $meta = $this->date_label($e['start'], $e['end']);
            if ($e['where']) $meta .= ' - ' . $e['where'];
            $items[] = ['kind' => 'event', 'title' => $e['title'], 'meta' => $meta, 'url' => $this->event_url($a['events_url'], $e['id'])];
        }
        foreach ($manual as $x) if (!$x['pin']) $items[] = $x;
        foreach (get_posts(['numberposts' => (int) $a['posts'], 'post_status' => 'publish']) as $p) {
            $items[] = ['kind' => 'blog', 'title' => get_the_title($p), 'meta' => get_the_date('j M Y', $p), 'url' => get_permalink($p)];
        }
        if (!$items) return '';
        $li = '';
        foreach ($items as $n => $it) {
            $kind = isset($labels[$it['kind']]) ? $it['kind'] : 'news';
            $li .= '<li class="tfh-item' . ($n === 0 ? ' is-active' : '') . '"><a href="' . esc_url($it['url']) . '"' . ($n === 0 ? '' : ' tabindex="-1"') . '>'
                 . '<span class="tfh-chip tfh-chip--' . esc_attr($kind) . '">' . esc_html($labels[$kind]) . '</span>'
                 . '<strong>' . esc_html($it['title']) . '</strong>'
                 . ($it['meta'] !== '' ? '<em>' . esc_html($it['meta']) . '</em>' : '')
                 . '<span class="tfh-go" aria-hidden="true">&rarr;</span></a></li>';
        }
        return $this->assets()
             . '<section class="tfh-banner" aria-label="Latest updates"><div class="tfh-banner__in">'
             . '<span class="tfh-label"><i class="tfh-pulse"></i><span class="tfh-label__t">Latest</span></span>'
             . '<div class="tfh-viewport"><ul class="tfh-list">' . $li . '</ul></div>'
             . '<div class="tfh-ctrl"><button type="button" class="tfh-prev" aria-label="Previous update">&lsaquo;</button><button type="button" class="tfh-next" aria-label="Next update">&rsaquo;</button></div>'
             . '</div></section>';
    }

    /* ---------- [tranter_home_events] ---------- */

    public function events($atts) {
        $a = shortcode_atts([
            'limit' => 4, 'events_url' => '/events/', 'eyebrow' => 'Events',
            'title' => 'Meet Tranter in the room',
            'lead' => 'Conferences, partner showcases and knowledge sessions. See what is next and revisit what you missed.',
        ], $atts, 'tranter_home_events');
        $limit = max(1, (int) $a['limit']);
        $ev = $this->load_events();
        $recent = false;
        $list = array_slice($ev[0], 0, $limit);
        if (!$list) {
            $list = array_slice($ev[1], 0, $limit);
            $recent = true;
        }
        if (!$list) return '';
        $f = array_shift($list);
        $furl = $this->event_url($a['events_url'], $f['id']);

        $feat = '<article class="tfh-feat">'
              . ($f['image'] ? '<img src="' . esc_url($f['image']) . '" alt="" loading="lazy">' : '')
              . '<div class="tfh-feat__shade"></div>'
              . '<div class="tfh-datebadge"><b>' . esc_html(wp_date('j', $f['start'])) . '</b><span>' . esc_html(wp_date('M', $f['start'])) . '</span></div>'
              . '<div class="tfh-feat__body"><span class="tfh-tag">' . esc_html($f['type']) . '</span>';
        $when = $recent ? '' : $this->when($f);
        if ($when) $feat .= '<span class="tfh-when">' . esc_html($when) . '</span>';
        $feat .= '<h3>' . esc_html($f['title']) . '</h3>';
        if ($f['short']) $feat .= '<p>' . esc_html($f['short']) . '</p>';
        $meta = $this->date_label($f['start'], $f['end']);
        if ($f['where']) $meta .= ' - ' . $f['where'];
        $feat .= '<div class="tfh-meta">' . esc_html($meta) . '</div><div class="tfh-actions">'
               . '<a class="tfh-btn" href="' . esc_url($furl) . '">View details &rarr;</a>';
        if (!$recent && $f['m']['registration_enabled'] === '1' && $f['m']['registration_url']) {
            $txt = $f['m']['registration_text'] ? $f['m']['registration_text'] : 'Register now';
            $feat .= '<a class="tfh-btn tfh-btn--light" href="' . esc_url($f['m']['registration_url']) . '" target="_blank" rel="noopener">' . esc_html($txt) . '</a>';
        }
        $feat .= '</div></div></article>';

        $rows = '';
        foreach ($list as $e) {
            $rows .= '<a class="tfh-ev" href="' . esc_url($this->event_url($a['events_url'], $e['id'])) . '">'
                   . '<span class="tfh-ev__img">' . ($e['image'] ? '<img src="' . esc_url($e['image']) . '" alt="" loading="lazy">' : '')
                   . '<i><b>' . esc_html(wp_date('j', $e['start'])) . '</b>' . esc_html(wp_date('M', $e['start'])) . '</i></span>'
                   . '<span class="tfh-ev__t"><small>' . esc_html($e['type']) . '</small><strong>' . esc_html($e['title']) . '</strong>'
                   . ($e['where'] ? '<em>' . esc_html($e['where']) . '</em>' : '') . '</span>'
                   . '<span class="tfh-go" aria-hidden="true">&rarr;</span></a>';
        }

        return $this->assets()
             . '<section class="tit-s tit-s--mist tfh-events" id="events"><div class="tit-in">'
             . '<div class="tit-head tit-center"><p class="tit-eyebrow">' . esc_html($a['eyebrow']) . '</p>'
             . '<h2 class="tit-h2">' . esc_html($recent ? 'Recent events' : $a['title']) . '</h2>'
             . '<p class="tit-lead">' . esc_html($a['lead']) . '</p></div>'
             . '<div class="tfh-grid' . ($rows ? '' : ' tfh-grid--solo') . '">' . $feat
             . ($rows ? '<div class="tfh-side">' . $rows . '</div>' : '') . '</div>'
             . '<div class="tfh-more"><a class="tfh-btn tfh-btn--ghost" href="' . esc_url($a['events_url']) . '">View all events &rarr;</a></div>'
             . '</div></section>';
    }
}
new Tranter_Home_Feed();
